# Katie Shi — Free Author Website

This is a one-file website. You only need `index.html`.

## Put it online with GitHub Pages
1. Create/sign into a GitHub account.
2. Create a new repository. A name like `katie-shi-site` works.
3. Set it to Public.
4. Upload `index.html`.
5. Open Settings → Pages.
6. Under Build and deployment, choose `Deploy from a branch`.
7. Select `main` and `/ (root)`, then Save.
8. GitHub will give you a free `https://YOUR-USERNAME.github.io/katie-shi-site/` address.

Before publishing, replace `YOUR-EMAIL-HERE` in `index.html` with an email you are comfortable making public, or remove that button.

The site is designed to match the screenshots you provided: cream, forest green, purple, gold, whimsical display typography, book cards, an author section, and an updates section.
